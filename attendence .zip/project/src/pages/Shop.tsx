import React, { useState } from 'react';
import { MealCard } from '../components/meals/MealCard';
import { HealthTracker } from '../components/health/HealthTracker';
import type { Meal } from '../types/meal';

// Mock data - replace with API call
const mockMeals: Meal[] = [
  {
    id: '1',
    name: 'Grilled Chicken Bowl',
    description: 'Tender grilled chicken with quinoa, roasted vegetables, and our signature sauce.',
    price: 12.99,
    imageUrl: 'https://images.pexels.com/photos/1234535/pexels-photo-1234535.jpeg',
    calories: 450,
    macros: {
      protein: 35,
      carbs: 45,
      fat: 15
    },
    ingredients: ['Chicken breast', 'Quinoa', 'Mixed vegetables', 'Olive oil'],
    preparationTime: 3,
    category: 'lunch'
  },
  {
    id: '2',
    name: 'Salmon & Sweet Potato',
    description: 'Wild-caught salmon with mashed sweet potato and steamed broccoli.',
    price: 14.99,
    imageUrl: 'https://images.pexels.com/photos/3655916/pexels-photo-3655916.jpeg',
    calories: 520,
    macros: {
      protein: 40,
      carbs: 35,
      fat: 22
    },
    ingredients: ['Salmon fillet', 'Sweet potato', 'Broccoli', 'Herbs'],
    preparationTime: 4,
    category: 'dinner'
  },
  {
    id: '3',
    name: 'Protein Breakfast Bowl',
    description: 'High-protein breakfast with eggs, turkey bacon, and whole grain toast.',
    price: 9.99,
    imageUrl: 'https://images.pexels.com/photos/1095550/pexels-photo-1095550.jpeg',
    calories: 380,
    macros: {
      protein: 28,
      carbs: 30,
      fat: 18
    },
    ingredients: ['Eggs', 'Turkey bacon', 'Whole grain bread', 'Avocado'],
    preparationTime: 2,
    category: 'breakfast'
  }
];

const Shop: React.FC = () => {
  const [category, setCategory] = useState<string>('all');
  
  const filteredMeals = category === 'all' 
    ? mockMeals 
    : mockMeals.filter(meal => meal.category === category);
  
  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-bold mb-8">Healthy Meals Delivered</h1>
      
      <div className="mb-8">
        <HealthTracker />
      </div>
      
      <div className="flex gap-4 mb-8">
        <button
          className={`btn ${category === 'all' ? 'btn-primary' : 'btn-outline'}`}
          onClick={() => setCategory('all')}
        >
          All Meals
        </button>
        <button
          className={`btn ${category === 'breakfast' ? 'btn-primary' : 'btn-outline'}`}
          onClick={() => setCategory('breakfast')}
        >
          Breakfast
        </button>
        <button
          className={`btn ${category === 'lunch' ? 'btn-primary' : 'btn-outline'}`}
          onClick={() => setCategory('lunch')}
        >
          Lunch
        </button>
        <button
          className={`btn ${category === 'dinner' ? 'btn-primary' : 'btn-outline'}`}
          onClick={() => setCategory('dinner')}
        >
          Dinner
        </button>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredMeals.map((meal) => (
          <MealCard key={meal.id} meal={meal} />
        ))}
      </div>
    </div>
  );
};

export default Shop;