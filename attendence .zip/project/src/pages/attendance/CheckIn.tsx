import React, { useState, useEffect } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { useAuth } from '../../contexts/AuthContext';
import { 
  Map, 
  Clock, 
  Copy, 
  CheckCircle, 
  RefreshCw, 
  Users, 
  Info,
  AlertCircle
} from 'lucide-react';

const CheckIn: React.FC = () => {
  const { currentUser } = useAuth();
  const [sessionId, setSessionId] = useState<string>('');
  const [sessionName, setSessionName] = useState<string>('');
  const [sessionDate, setSessionDate] = useState<string>('');
  const [sessionTime, setSessionTime] = useState<string>('');
  const [expiresIn, setExpiresIn] = useState<number>(15 * 60); // 15 minutes in seconds
  const [copied, setCopied] = useState<boolean>(false);
  const [qrValue, setQrValue] = useState<string>('');
  const [location, setLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [locationError, setLocationError] = useState<string | null>(null);
  
  // Only instructors and admins can create QR codes
  const canCreateQR = currentUser?.role === 'instructor' || currentUser?.role === 'admin';
  
  // Mock sessions data
  const mockSessions = [
    { id: 'cs101', name: 'CS101: Intro to Programming' },
    { id: 'cs201', name: 'CS201: Software Engineering' },
    { id: 'cs301', name: 'CS301: Data Structures' },
    { id: 'cs401', name: 'CS401: Algorithms' },
  ];

  const requestLocation = () => {
    setLocationError(null);
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
          setLocationError(null);
        },
        (error) => {
          let errorMessage = 'Error getting location. Please try again.';
          
          if (error.code === 1) { // PERMISSION_DENIED
            errorMessage = 'Location access denied. Please enable location services in your browser settings to use this feature.';
          } else if (error.code === 2) { // POSITION_UNAVAILABLE
            errorMessage = 'Location information is unavailable. Please check your device settings.';
          } else if (error.code === 3) { // TIMEOUT
            errorMessage = 'Location request timed out. Please try again.';
          }
          
          setLocationError(errorMessage);
          setLocation(null);
          console.log('Geolocation error:', error);
        },
        {
          enableHighAccuracy: true,
          timeout: 5000,
          maximumAge: 0
        }
      );
    } else {
      setLocationError('Geolocation is not supported by your browser.');
      setLocation(null);
    }
  };
  
  // Initialize with default date and time
  useEffect(() => {
    const today = new Date();
    setSessionDate(today.toISOString().split('T')[0]);
    
    const hours = today.getHours();
    const minutes = today.getMinutes();
    setSessionTime(`${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}`);
    
    requestLocation();
  }, []);
  
  // Generate QR code value when session info changes
  useEffect(() => {
    if (sessionId && sessionDate && sessionTime && location) {
      const qrData = {
        sessionId,
        sessionName: mockSessions.find(s => s.id === sessionId)?.name || '',
        date: sessionDate,
        time: sessionTime,
        location,
        createdBy: currentUser?.id,
        expiresAt: new Date(Date.now() + expiresIn * 1000).toISOString(),
      };
      
      setQrValue(JSON.stringify(qrData));
    }
  }, [sessionId, sessionDate, sessionTime, location, expiresIn, currentUser]);
  
  // Countdown timer for QR code expiration
  useEffect(() => {
    if (expiresIn <= 0) return;
    
    const timer = setInterval(() => {
      setExpiresIn((prev) => prev - 1);
    }, 1000);
    
    return () => clearInterval(timer);
  }, [expiresIn]);
  
  // Format time remaining
  const formatTimeRemaining = () => {
    const minutes = Math.floor(expiresIn / 60);
    const seconds = expiresIn % 60;
    return `${minutes}:${seconds.toString().padStart(2, '0')}`;
  };
  
  // Handle session selection
  const handleSessionChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    setSessionId(e.target.value);
    const session = mockSessions.find(s => s.id === e.target.value);
    if (session) {
      setSessionName(session.name);
    }
  };
  
  // Generate new QR code
  const regenerateQR = () => {
    // Reset expiration time
    setExpiresIn(15 * 60);
    
    // Update current time
    const now = new Date();
    setSessionTime(`${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`);
    
    requestLocation();
  };
  
  // Copy session link to clipboard
  const copySessionLink = () => {
    const sessionLink = `${window.location.origin}/scan?data=${encodeURIComponent(qrValue)}`;
    navigator.clipboard.writeText(sessionLink).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    });
  };
  
  if (!canCreateQR) {
    return (
      <div className="animate-fade-in">
        <div className="flex items-center justify-center h-64">
          <div className="text-center max-w-md">
            <AlertCircle className="h-16 w-16 text-warning-500 mx-auto mb-4" />
            <h2 className="text-xl font-semibold mb-2">Access Restricted</h2>
            <p className="text-gray-600">
              Only instructors and administrators can generate QR codes for attendance. 
              If you're a student, please use the Scan QR option instead.
            </p>
          </div>
        </div>
      </div>
    );
  }
  
  return (
    <div className="animate-fade-in">
      <h1 className="text-2xl font-bold mb-6">Generate Attendance QR Code</h1>
      
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
        {/* QR Code Generator Form */}
        <div className="card">
          <h2 className="text-lg font-semibold mb-4">Session Information</h2>
          
          <div className="space-y-4">
            <div>
              <label htmlFor="session" className="form-label">Select Class/Session</label>
              <select
                id="session"
                value={sessionId}
                onChange={handleSessionChange}
                className="form-input"
                required
              >
                <option value="">Select a session</option>
                {mockSessions.map((session) => (
                  <option key={session.id} value={session.id}>
                    {session.name}
                  </option>
                ))}
              </select>
            </div>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label htmlFor="date" className="form-label">Date</label>
                <input
                  id="date"
                  type="date"
                  value={sessionDate}
                  onChange={(e) => setSessionDate(e.target.value)}
                  className="form-input"
                  required
                />
              </div>
              
              <div>
                <label htmlFor="time" className="form-label">Time</label>
                <input
                  id="time"
                  type="time"
                  value={sessionTime}
                  onChange={(e) => setSessionTime(e.target.value)}
                  className="form-input"
                  required
                />
              </div>
            </div>
            
            <div>
              <label htmlFor="location" className="form-label flex items-center gap-1">
                Location
                {location && !locationError ? (
                  <span className="inline-flex items-center rounded-full bg-success-100 px-2 py-0.5 text-xs font-medium text-success-800 ml-2">
                    <CheckCircle className="h-3 w-3 mr-1" />
                    Detected
                  </span>
                ) : !locationError ? (
                  <span className="inline-flex items-center rounded-full bg-warning-100 px-2 py-0.5 text-xs font-medium text-warning-800 ml-2">
                    Detecting...
                  </span>
                ) : (
                  <span className="inline-flex items-center rounded-full bg-error-100 px-2 py-0.5 text-xs font-medium text-error-800 ml-2">
                    <AlertCircle className="h-3 w-3 mr-1" />
                    Error
                  </span>
                )}
              </label>
              <div className="flex items-center gap-2">
                <input
                  id="location"
                  type="text"
                  value={
                    locationError
                      ? 'Location access required'
                      : location
                        ? `${location.latitude.toFixed(6)}, ${location.longitude.toFixed(6)}`
                        : 'Detecting location...'
                  }
                  className="form-input"
                  disabled
                />
                <button 
                  type="button"
                  onClick={requestLocation}
                  className="btn btn-outline btn-sm"
                  title={locationError ? "Retry location access" : "Refresh location"}
                >
                  <Map size={16} />
                </button>
              </div>
              {locationError ? (
                <p className="text-sm text-error-600 mt-1">
                  {locationError}
                </p>
              ) : (
                <p className="text-xs text-gray-500 mt-1">
                  Location is used to verify attendance within the classroom vicinity.
                </p>
              )}
            </div>
            
            <div>
              <label htmlFor="expiration" className="form-label">QR Code Expiration</label>
              <select
                id="expiration"
                value={expiresIn}
                onChange={(e) => setExpiresIn(parseInt(e.target.value))}
                className="form-input"
              >
                <option value={300}>5 minutes</option>
                <option value={600}>10 minutes</option>
                <option value={900}>15 minutes</option>
                <option value={1800}>30 minutes</option>
                <option value={3600}>1 hour</option>
              </select>
            </div>
          </div>
          
          <div className="flex justify-end mt-6">
            <button 
              onClick={regenerateQR}
              className="btn btn-primary"
              disabled={!sessionId || !!locationError}
            >
              <RefreshCw size={16} />
              Regenerate QR Code
            </button>
          </div>
        </div>
        
        {/* QR Code Display */}
        <div className="card flex flex-col items-center">
          <h2 className="text-lg font-semibold mb-4 self-start">Attendance QR Code</h2>
          
          {!sessionId || locationError ? (
            <div className="flex flex-col items-center justify-center h-full">
              <Info size={48} className="text-gray-300 mb-4" />
              <p className="text-gray-500 text-center">
                {locationError
                  ? "Location access is required to generate the QR code."
                  : "Select a session and fill in the details to generate a QR code."}
              </p>
            </div>
          ) : (
            <>
              <div className="bg-white p-4 rounded-lg shadow-sm border border-gray-200 mb-4">
                <QRCodeSVG 
                  value={qrValue} 
                  size={250}
                  level="H"
                  includeMargin
                  fgColor="#000"
                  bgColor="#FFF"
                />
              </div>
              
              <div className="w-full space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Clock className="h-5 w-5 text-warning-500 mr-2" />
                    <span className="font-medium">Expires in:</span>
                  </div>
                  <span className="font-mono bg-warning-50 text-warning-700 px-3 py-1 rounded-md">
                    {formatTimeRemaining()}
                  </span>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <Users className="h-5 w-5 text-primary-500 mr-2" />
                    <span className="font-medium">Session:</span>
                  </div>
                  <span className="text-gray-700 truncate max-w-[200px]">
                    {sessionName || 'N/A'}
                  </span>
                </div>
                
                <button
                  onClick={copySessionLink}
                  className={`btn w-full ${copied ? 'btn-success' : 'btn-outline'}`}
                >
                  {copied ? (
                    <>
                      <CheckCircle size={16} />
                      Copied to clipboard!
                    </>
                  ) : (
                    <>
                      <Copy size={16} />
                      Copy session link
                    </>
                  )}
                </button>
                
                <p className="text-sm text-gray-500 text-center mt-2">
                  Students can scan this QR code or use the link to check in.
                </p>
              </div>
            </>
          )}
        </div>
      </div>
      
      <div className="mt-8 card bg-primary-50 p-4">
        <div className="flex items-start gap-3">
          <Info className="h-5 w-5 text-primary-600 flex-shrink-0 mt-0.5" />
          <div>
            <h3 className="font-medium text-primary-700">How it works</h3>
            <p className="text-sm text-primary-600 mt-1">
              This QR code contains encrypted session information including location, time, and expiration. 
              When students scan the code, their location is verified against the classroom location, 
              and attendance is only marked if they are physically present within the allowed radius.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CheckIn;