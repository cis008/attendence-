import React, { useState } from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { 
  Check, 
  X, 
  Calendar, 
  Clock, 
  Download, 
  Filter, 
  Search,
  ArrowUp,
  ArrowDown
} from 'lucide-react';

// Mock attendance data
const mockAttendanceHistory = [
  {
    id: 1,
    sessionId: 'cs101-2025-01-07',
    sessionName: 'CS101: Intro to Programming',
    date: '2025-01-07',
    time: '09:00',
    status: 'absent',
    notes: 'Email notification sent',
  },
  {
    id: 2,
    sessionId: 'cs201-2025-01-06',
    sessionName: 'CS201: Software Engineering',
    date: '2025-01-06',
    time: '14:00',
    status: 'present',
    notes: 'Checked in via QR code',
  },
  {
    id: 3,
    sessionId: 'cs301-2025-01-06',
    sessionName: 'CS301: Data Structures',
    date: '2025-01-06',
    time: '10:00',
    status: 'present',
    notes: 'Checked in via QR code',
  },
  {
    id: 4,
    sessionId: 'cs401-2025-01-05',
    sessionName: 'CS401: Algorithms',
    date: '2025-01-05',
    time: '15:30',
    status: 'late',
    notes: 'Checked in 10 minutes late',
  },
  {
    id: 5,
    sessionId: 'cs101-2025-01-05',
    sessionName: 'CS101: Intro to Programming',
    date: '2025-01-05',
    time: '09:00',
    status: 'present',
    notes: 'Checked in via QR code',
  },
  {
    id: 6,
    sessionId: 'cs201-2025-01-04',
    sessionName: 'CS201: Software Engineering',
    date: '2025-01-04',
    time: '14:00',
    status: 'present',
    notes: 'Checked in via QR code',
  },
  {
    id: 7,
    sessionId: 'cs301-2025-01-04',
    sessionName: 'CS301: Data Structures',
    date: '2025-01-04',
    time: '10:00',
    status: 'present',
    notes: 'Checked in via QR code',
  },
  {
    id: 8,
    sessionId: 'cs401-2025-01-03',
    sessionName: 'CS401: Algorithms',
    date: '2025-01-03',
    time: '15:30',
    status: 'absent',
    notes: 'Email notification sent',
  },
];

const History: React.FC = () => {
  const { currentUser } = useAuth();
  const isAdmin = currentUser?.role === 'admin';
  const isInstructor = currentUser?.role === 'instructor';
  
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [dateRange, setDateRange] = useState({ start: '', end: '' });
  const [sortField, setSortField] = useState<'date' | 'sessionName'>('date');
  const [sortDirection, setSortDirection] = useState<'asc' | 'desc'>('desc');
  
  // Apply filters and search
  const filteredHistory = mockAttendanceHistory.filter(record => {
    // Status filter
    if (statusFilter !== 'all' && record.status !== statusFilter) {
      return false;
    }
    
    // Date range filter
    if (dateRange.start && new Date(record.date) < new Date(dateRange.start)) {
      return false;
    }
    if (dateRange.end && new Date(record.date) > new Date(dateRange.end)) {
      return false;
    }
    
    // Search term
    if (
      searchTerm &&
      !record.sessionName.toLowerCase().includes(searchTerm.toLowerCase()) &&
      !record.date.includes(searchTerm)
    ) {
      return false;
    }
    
    return true;
  });
  
  // Apply sorting
  const sortedHistory = [...filteredHistory].sort((a, b) => {
    if (sortField === 'date') {
      const dateComparison = new Date(a.date).getTime() - new Date(b.date).getTime();
      return sortDirection === 'asc' ? dateComparison : -dateComparison;
    } else {
      const nameComparison = a.sessionName.localeCompare(b.sessionName);
      return sortDirection === 'asc' ? nameComparison : -nameComparison;
    }
  });
  
  // Toggle sort direction
  const toggleSort = (field: 'date' | 'sessionName') => {
    if (sortField === field) {
      setSortDirection(sortDirection === 'asc' ? 'desc' : 'asc');
    } else {
      setSortField(field);
      setSortDirection('asc');
    }
  };
  
  // Download attendance report (mock function)
  const downloadReport = () => {
    alert('Downloading attendance report...');
    // In a real app, this would generate and download a CSV or PDF report
  };
  
  return (
    <div className="animate-fade-in">
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900 mb-2 sm:mb-0">Attendance History</h1>
        
        <div className="flex items-center gap-2">
          <button
            onClick={downloadReport}
            className="btn btn-outline btn-sm flex items-center gap-1"
          >
            <Download size={16} />
            Export
          </button>
          
          {(isAdmin || isInstructor) && (
            <button className="btn btn-primary btn-sm">
              Generate Report
            </button>
          )}
        </div>
      </div>
      
      {/* Filters */}
      <div className="card mb-6">
        <div className="flex items-center gap-2 mb-4">
          <Filter size={16} className="text-gray-500" />
          <h2 className="text-lg font-semibold">Filters</h2>
        </div>
        
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          <div>
            <label htmlFor="search" className="form-label">Search</label>
            <div className="relative">
              <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none">
                <Search size={16} className="text-gray-400" />
              </div>
              <input
                id="search"
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by class or date"
                className="form-input pl-10"
              />
            </div>
          </div>
          
          <div>
            <label htmlFor="status" className="form-label">Status</label>
            <select
              id="status"
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="form-input"
            >
              <option value="all">All Statuses</option>
              <option value="present">Present</option>
              <option value="late">Late</option>
              <option value="absent">Absent</option>
            </select>
          </div>
          
          <div>
            <label htmlFor="startDate" className="form-label">Start Date</label>
            <input
              id="startDate"
              type="date"
              value={dateRange.start}
              onChange={(e) => setDateRange({ ...dateRange, start: e.target.value })}
              className="form-input"
            />
          </div>
          
          <div>
            <label htmlFor="endDate" className="form-label">End Date</label>
            <input
              id="endDate"
              type="date"
              value={dateRange.end}
              onChange={(e) => setDateRange({ ...dateRange, end: e.target.value })}
              className="form-input"
            />
          </div>
        </div>
      </div>
      
      {/* Attendance History Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Status
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => toggleSort('sessionName')}
                >
                  <div className="flex items-center">
                    Class/Session
                    {sortField === 'sessionName' && (
                      sortDirection === 'asc' ? <ArrowUp size={14} className="ml-1" /> : <ArrowDown size={14} className="ml-1" />
                    )}
                  </div>
                </th>
                <th 
                  scope="col" 
                  className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider cursor-pointer"
                  onClick={() => toggleSort('date')}
                >
                  <div className="flex items-center">
                    Date & Time
                    {sortField === 'date' && (
                      sortDirection === 'asc' ? <ArrowUp size={14} className="ml-1" /> : <ArrowDown size={14} className="ml-1" />
                    )}
                  </div>
                </th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                  Notes
                </th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {sortedHistory.length > 0 ? (
                sortedHistory.map((record) => (
                  <tr key={record.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center">
                        {record.status === 'present' && (
                          <div className="flex items-center rounded-full bg-success-100 px-2.5 py-0.5 text-sm font-medium text-success-800">
                            <Check size={14} className="mr-1" />
                            Present
                          </div>
                        )}
                        {record.status === 'late' && (
                          <div className="flex items-center rounded-full bg-warning-100 px-2.5 py-0.5 text-sm font-medium text-warning-800">
                            <Clock size={14} className="mr-1" />
                            Late
                          </div>
                        )}
                        {record.status === 'absent' && (
                          <div className="flex items-center rounded-full bg-error-100 px-2.5 py-0.5 text-sm font-medium text-error-800">
                            <X size={14} className="mr-1" />
                            Absent
                          </div>
                        )}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">{record.sessionName}</div>
                      <div className="text-sm text-gray-500">Session ID: {record.sessionId}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="flex items-center text-sm text-gray-900">
                        <Calendar size={14} className="mr-1" />
                        {new Date(record.date).toLocaleDateString()}
                      </div>
                      <div className="flex items-center text-sm text-gray-500">
                        <Clock size={14} className="mr-1" />
                        {record.time}
                      </div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {record.notes}
                    </td>
                  </tr>
                ))
              ) : (
                <tr>
                  <td colSpan={4} className="px-6 py-4 whitespace-nowrap text-center text-gray-500">
                    No attendance records found matching your filters.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
      
      {/* Summary Statistics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6 mt-6">
        <div className="card bg-primary-50 flex items-center">
          <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary-100">
            <Check className="h-6 w-6 text-primary-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-primary-800">Present</p>
            <p className="text-2xl font-semibold text-primary-900">
              {filteredHistory.filter(r => r.status === 'present').length}
            </p>
          </div>
        </div>
        
        <div className="card bg-warning-50 flex items-center">
          <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-warning-100">
            <Clock className="h-6 w-6 text-warning-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-warning-800">Late</p>
            <p className="text-2xl font-semibold text-warning-900">
              {filteredHistory.filter(r => r.status === 'late').length}
            </p>
          </div>
        </div>
        
        <div className="card bg-error-50 flex items-center">
          <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-error-100">
            <X className="h-6 w-6 text-error-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-error-800">Absent</p>
            <p className="text-2xl font-semibold text-error-900">
              {filteredHistory.filter(r => r.status === 'absent').length}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default History;