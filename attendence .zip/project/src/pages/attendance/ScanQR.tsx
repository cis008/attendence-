import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useAuth } from '../../contexts/AuthContext';
import { 
  QrCode, 
  CheckCircle2, 
  XCircle, 
  MapPin, 
  Clock, 
  AlertCircle,
  Camera,
  User,
  Calendar
} from 'lucide-react';

const ScanQR: React.FC = () => {
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  
  // States for QR scanning and attendance
  const [scanState, setScanState] = useState<'idle' | 'scanning' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState<string>('');
  const [sessionData, setSessionData] = useState<any>(null);
  const [userLocation, setUserLocation] = useState<{ latitude: number; longitude: number } | null>(null);
  const [distance, setDistance] = useState<number | null>(null);
  
  // Parse QR data from URL if available
  useEffect(() => {
    const qrData = searchParams.get('data');
    if (qrData) {
      try {
        const parsedData = JSON.parse(decodeURIComponent(qrData));
        setSessionData(parsedData);
        checkAttendanceEligibility(parsedData);
      } catch (error) {
        console.error('Error parsing QR data:', error);
        setScanState('error');
        setErrorMessage('Invalid QR code data. Please try scanning again.');
      }
    }
  }, [searchParams]);
  
  // Get user location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
        },
        (error) => {
          console.error('Error getting location:', error);
          setScanState('error');
          setErrorMessage('Unable to access your location. Please enable location services and try again.');
        }
      );
    } else {
      setScanState('error');
      setErrorMessage('Your device does not support location services, which is required for attendance verification.');
    }
  }, []);
  
  // Calculate distance between two coordinates in meters
  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number): number => {
    const R = 6371e3; // Earth radius in meters
    const φ1 = (lat1 * Math.PI) / 180;
    const φ2 = (lat2 * Math.PI) / 180;
    const Δφ = ((lat2 - lat1) * Math.PI) / 180;
    const Δλ = ((lon2 - lon1) * Math.PI) / 180;
    
    const a =
      Math.sin(Δφ / 2) * Math.sin(Δφ / 2) +
      Math.cos(φ1) * Math.cos(φ2) * Math.sin(Δλ / 2) * Math.sin(Δλ / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    
    return R * c;
  };
  
  // Check if user is eligible to mark attendance
  const checkAttendanceEligibility = (data: any) => {
    setScanState('scanning');
    
    // Simulate processing
    setTimeout(() => {
      // Check if session has expired
      const expiresAt = new Date(data.expiresAt);
      if (expiresAt < new Date()) {
        setScanState('error');
        setErrorMessage('This QR code has expired. Please ask for a new code.');
        return;
      }
      
      // Check if user location is available
      if (!userLocation) {
        setScanState('error');
        setErrorMessage('Unable to verify your location. Please enable location services and try again.');
        return;
      }
      
      // Calculate distance between user and session location
      const distanceInMeters = calculateDistance(
        userLocation.latitude,
        userLocation.longitude,
        data.location.latitude,
        data.location.longitude
      );
      
      setDistance(distanceInMeters);
      
      // Allow attendance if within 200 meters of the session location
      const maxAllowedDistance = 200; // meters
      if (distanceInMeters <= maxAllowedDistance) {
        setScanState('success');
        
        // Mock API call to mark attendance
        // In a real app, this would be an API call to the server
        console.log('Marking attendance for:', {
          userId: currentUser?.id,
          userName: currentUser?.name,
          sessionId: data.sessionId,
          sessionName: data.sessionName,
          timestamp: new Date().toISOString(),
          location: userLocation,
        });
      } else {
        setScanState('error');
        setErrorMessage(`You appear to be ${Math.round(distanceInMeters)} meters away from the class location. You must be within ${maxAllowedDistance} meters to mark attendance.`);
      }
    }, 2000);
  };
  
  // Handle manual QR scan (mock function)
  const handleScanClick = () => {
    setScanState('scanning');
    
    // Mock scanning process
    setTimeout(() => {
      // Simulate a successful scan with mock data
      const mockData = {
        sessionId: 'cs101',
        sessionName: 'CS101: Intro to Programming',
        date: new Date().toISOString().split('T')[0],
        time: `${new Date().getHours()}:${new Date().getMinutes()}`,
        location: {
          latitude: userLocation ? userLocation.latitude + 0.0001 : 0, // Slightly offset for testing
          longitude: userLocation ? userLocation.longitude + 0.0001 : 0,
        },
        createdBy: 'instructor-1',
        expiresAt: new Date(Date.now() + 15 * 60 * 1000).toISOString(), // 15 minutes from now
      };
      
      setSessionData(mockData);
      checkAttendanceEligibility(mockData);
    }, 2000);
  };
  
  // Return to dashboard
  const handleReturn = () => {
    navigate('/dashboard');
  };
  
  return (
    <div className="animate-fade-in">
      <h1 className="text-2xl font-bold mb-6">Scan Attendance QR Code</h1>
      
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-2">
        {/* QR Scanner */}
        <div className="card flex flex-col items-center">
          <h2 className="text-lg font-semibold mb-4 self-start">Scan QR Code</h2>
          
          {scanState === 'idle' && (
            <div className="flex flex-col items-center justify-center h-64 w-full">
              <div className="mb-6 bg-gray-100 rounded-lg p-6 flex items-center justify-center">
                <Camera className="h-16 w-16 text-gray-400" />
              </div>
              <p className="text-gray-600 mb-6 text-center">
                Position the QR code within the camera view to check in for your class.
              </p>
              <button onClick={handleScanClick} className="btn btn-primary">
                <QrCode size={18} className="mr-2" />
                Scan QR Code
              </button>
            </div>
          )}
          
          {scanState === 'scanning' && (
            <div className="flex flex-col items-center justify-center h-64">
              <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-primary-600 mb-4"></div>
              <p className="text-gray-600">Verifying your attendance...</p>
              {userLocation && (
                <p className="text-xs text-gray-500 mt-2">
                  Your location: {userLocation.latitude.toFixed(6)}, {userLocation.longitude.toFixed(6)}
                </p>
              )}
            </div>
          )}
          
          {scanState === 'success' && (
            <div className="flex flex-col items-center justify-center h-64 w-full">
              <div className="mb-4 text-success-500 check-in-success">
                <CheckCircle2 className="h-16 w-16" />
              </div>
              <h3 className="text-xl font-semibold text-success-700 mb-2">Attendance Recorded!</h3>
              <p className="text-gray-600 mb-6 text-center">
                Your attendance has been successfully recorded for this session.
              </p>
              <button onClick={handleReturn} className="btn btn-success">
                Return to Dashboard
              </button>
            </div>
          )}
          
          {scanState === 'error' && (
            <div className="flex flex-col items-center justify-center h-64 w-full">
              <div className="mb-4 text-error-500">
                <XCircle className="h-16 w-16" />
              </div>
              <h3 className="text-xl font-semibold text-error-700 mb-2">Check-in Failed</h3>
              <p className="text-gray-600 mb-6 text-center">
                {errorMessage}
              </p>
              <button onClick={() => setScanState('idle')} className="btn btn-outline">
                Try Again
              </button>
            </div>
          )}
          
          {/* Location requirement notice */}
          <div className="w-full mt-6 bg-gray-50 p-4 rounded-lg border border-gray-200">
            <div className="flex items-start gap-3">
              <AlertCircle className="h-5 w-5 text-warning-500 flex-shrink-0 mt-0.5" />
              <div>
                <h3 className="font-medium">Location Required</h3>
                <p className="text-sm text-gray-600 mt-1">
                  To verify your attendance, we need to confirm you're present at the class location. 
                  Please ensure location services are enabled on your device.
                </p>
              </div>
            </div>
          </div>
        </div>
        
        {/* Attendance Information */}
        <div className="card">
          <h2 className="text-lg font-semibold mb-4">Attendance Information</h2>
          
          {!sessionData ? (
            <div className="flex flex-col items-center justify-center h-64">
              <QrCode className="h-16 w-16 text-gray-300 mb-4" />
              <p className="text-gray-500 text-center">
                Scan a QR code to view session information and record your attendance.
              </p>
            </div>
          ) : (
            <div className="space-y-6">
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Calendar className="h-5 w-5 text-primary-500" />
                  <h3 className="font-semibold">Session Details</h3>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="font-medium text-gray-800">{sessionData.sessionName}</p>
                  <div className="flex items-center text-sm text-gray-600 mt-2">
                    <Clock className="h-4 w-4 mr-1" />
                    <span>{new Date(sessionData.date).toLocaleDateString()} at {sessionData.time}</span>
                  </div>
                </div>
              </div>
              
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <MapPin className="h-5 w-5 text-primary-500" />
                  <h3 className="font-semibold">Location</h3>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-600">
                    Class location: {sessionData.location.latitude.toFixed(6)}, {sessionData.location.longitude.toFixed(6)}
                  </p>
                  
                  {distance !== null && (
                    <div className={`mt-2 text-sm ${distance <= 200 ? 'text-success-600' : 'text-error-600'}`}>
                      You are approximately {Math.round(distance)} meters from the class location.
                    </div>
                  )}
                </div>
              </div>
              
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <User className="h-5 w-5 text-primary-500" />
                  <h3 className="font-semibold">Student Information</h3>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="font-medium text-gray-800">{currentUser?.name}</p>
                  <p className="text-sm text-gray-600 mt-1">{currentUser?.email}</p>
                </div>
              </div>
              
              <div>
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="h-5 w-5 text-primary-500" />
                  <h3 className="font-semibold">QR Code Validity</h3>
                </div>
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm text-gray-600">
                    Expires at: {new Date(sessionData.expiresAt).toLocaleTimeString()}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ScanQR;