import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { 
  QrCode, 
  Users, 
  CalendarDays, 
  ClipboardCheck,
  Clock,
  ArrowUpRight,
  ChevronRight,
  Bell,
  CheckCircle2,
  XCircle,
  Settings,
} from 'lucide-react';
import { AttendanceStats } from '../components/dashboard/AttendanceStats';
import { RecentActivity } from '../components/dashboard/RecentActivity';
import { UpcomingSessions } from '../components/dashboard/UpcomingSessions';

// Mock data for attendance stats
const mockAttendanceData = [
  { date: '2025-01-01', present: 85, absent: 15 },
  { date: '2025-01-02', present: 90, absent: 10 },
  { date: '2025-01-03', present: 75, absent: 25 },
  { date: '2025-01-04', present: 95, absent: 5 },
  { date: '2025-01-05', present: 80, absent: 20 },
  { date: '2025-01-06', present: 92, absent: 8 },
  { date: '2025-01-07', present: 88, absent: 12 },
];

const Dashboard: React.FC = () => {
  const { currentUser } = useAuth();
  const [selectedPeriod, setSelectedPeriod] = useState('week');
  
  // Conditional rendering based on user role
  const renderDashboardContent = () => {
    switch (currentUser?.role) {
      case 'admin':
        return <AdminDashboard />;
      case 'instructor':
        return <InstructorDashboard />;
      case 'student':
        return <StudentDashboard />;
      default:
        return <div>Unknown user role</div>;
    }
  };
  
  return (
    <div className="animate-fade-in">
      <div className="mb-6 flex flex-col sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-2xl font-bold text-gray-900 mb-2 sm:mb-0">Dashboard</h1>
        
        <div className="flex space-x-2">
          <button
            className={`btn btn-sm ${
              selectedPeriod === 'week' ? 'btn-primary' : 'btn-outline'
            }`}
            onClick={() => setSelectedPeriod('week')}
          >
            Week
          </button>
          <button
            className={`btn btn-sm ${
              selectedPeriod === 'month' ? 'btn-primary' : 'btn-outline'
            }`}
            onClick={() => setSelectedPeriod('month')}
          >
            Month
          </button>
          <button
            className={`btn btn-sm ${
              selectedPeriod === 'semester' ? 'btn-primary' : 'btn-outline'
            }`}
            onClick={() => setSelectedPeriod('semester')}
          >
            Semester
          </button>
        </div>
      </div>

      {renderDashboardContent()}
    </div>
  );
};

const AdminDashboard: React.FC = () => {
  return (
    <div>
      {/* Summary stats */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4 mb-8">
        <div className="card flex items-center">
          <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary-100">
            <Users className="h-6 w-6 text-primary-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Total Users</p>
            <p className="text-2xl font-semibold">1,248</p>
          </div>
        </div>
        
        <div className="card flex items-center">
          <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-success-100">
            <CalendarDays className="h-6 w-6 text-success-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Active Sessions</p>
            <p className="text-2xl font-semibold">24</p>
          </div>
        </div>
        
        <div className="card flex items-center">
          <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-accent-100">
            <ClipboardCheck className="h-6 w-6 text-accent-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Avg. Attendance</p>
            <p className="text-2xl font-semibold">87%</p>
          </div>
        </div>
        
        <div className="card flex items-center">
          <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-warning-100">
            <Bell className="h-6 w-6 text-warning-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Alerts</p>
            <p className="text-2xl font-semibold">12</p>
          </div>
        </div>
      </div>
      
      {/* Attendance trends and activity */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2">
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Attendance Trends</h2>
              <Link to="/reports" className="flex items-center text-sm text-primary-600 hover:text-primary-500">
                View full reports
                <ArrowUpRight className="ml-1 h-4 w-4" />
              </Link>
            </div>
            <AttendanceStats data={mockAttendanceData} />
          </div>
        </div>
        
        <div>
          <div className="card h-full">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Recent Activity</h2>
              <Link to="/history" className="flex items-center text-sm text-primary-600 hover:text-primary-500">
                View all
                <ArrowUpRight className="ml-1 h-4 w-4" />
              </Link>
            </div>
            <RecentActivity />
          </div>
        </div>
      </div>
      
      {/* Admin quick actions and alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <div className="card">
            <h2 className="text-lg font-semibold mb-4">Quick Actions</h2>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <Link to="/sessions/new" className="card bg-primary-50 hover:bg-primary-100 transition-colors">
                <div className="flex flex-col items-center justify-center py-4">
                  <CalendarDays className="h-8 w-8 text-primary-600 mb-2" />
                  <span className="font-medium">Create Session</span>
                </div>
              </Link>
              
              <Link to="/users/invite" className="card bg-secondary-50 hover:bg-secondary-100 transition-colors">
                <div className="flex flex-col items-center justify-center py-4">
                  <Users className="h-8 w-8 text-secondary-600 mb-2" />
                  <span className="font-medium">Invite Users</span>
                </div>
              </Link>
              
              <Link to="/reports/generate" className="card bg-accent-50 hover:bg-accent-100 transition-colors">
                <div className="flex flex-col items-center justify-center py-4">
                  <ClipboardCheck className="h-8 w-8 text-accent-600 mb-2" />
                  <span className="font-medium">Generate Reports</span>
                </div>
              </Link>
            </div>
          </div>
        </div>
        
        <div>
          <div className="card h-full">
            <h2 className="text-lg font-semibold mb-4">System Alerts</h2>
            <div className="space-y-4">
              <div className="flex items-start gap-3 p-3 rounded-md bg-warning-50">
                <Bell className="h-5 w-5 text-warning-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-warning-700">Low attendance detected</p>
                  <p className="text-sm text-warning-600">CS101 has attendance below 70% for the past week.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3 p-3 rounded-md bg-success-50">
                <CheckCircle2 className="h-5 w-5 text-success-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-success-700">Email integration active</p>
                  <p className="text-sm text-success-600">Gmail notifications are working properly.</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3 p-3 rounded-md bg-error-50">
                <XCircle className="h-5 w-5 text-error-600 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="font-medium text-error-700">QR code scanning issue</p>
                  <p className="text-sm text-error-600">Some users reported problems with QR scanning.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const InstructorDashboard: React.FC = () => {
  return (
    <div>
      {/* Summary stats */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4 mb-8">
        <div className="card flex items-center">
          <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary-100">
            <Users className="h-6 w-6 text-primary-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Total Students</p>
            <p className="text-2xl font-semibold">156</p>
          </div>
        </div>
        
        <div className="card flex items-center">
          <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-success-100">
            <CalendarDays className="h-6 w-6 text-success-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">My Classes</p>
            <p className="text-2xl font-semibold">4</p>
          </div>
        </div>
        
        <div className="card flex items-center">
          <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-accent-100">
            <ClipboardCheck className="h-6 w-6 text-accent-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Avg. Attendance</p>
            <p className="text-2xl font-semibold">92%</p>
          </div>
        </div>
        
        <div className="card flex items-center">
          <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-warning-100">
            <Bell className="h-6 w-6 text-warning-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Absent Today</p>
            <p className="text-2xl font-semibold">7</p>
          </div>
        </div>
      </div>
      
      {/* Class attendance and upcoming sessions */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div className="lg:col-span-2">
          <div className="card">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Class Attendance</h2>
              <div className="flex gap-2">
                <select className="form-input py-1 text-sm">
                  <option>All Classes</option>
                  <option>CS101</option>
                  <option>CS201</option>
                  <option>CS301</option>
                  <option>CS401</option>
                </select>
              </div>
            </div>
            <AttendanceStats data={mockAttendanceData} />
          </div>
        </div>
        
        <div>
          <div className="card h-full">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Upcoming Sessions</h2>
              <Link to="/sessions" className="flex items-center text-sm text-primary-600 hover:text-primary-500">
                View all
                <ArrowUpRight className="ml-1 h-4 w-4" />
              </Link>
            </div>
            <UpcomingSessions />
          </div>
        </div>
      </div>
      
      {/* Instructor quick actions */}
      <div className="grid grid-cols-1 gap-6">
        <div className="card">
          <h2 className="text-lg font-semibold mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
            <Link to="/check-in" className="card bg-primary-50 hover:bg-primary-100 transition-colors">
              <div className="flex flex-col items-center justify-center py-4">
                <QrCode className="h-8 w-8 text-primary-600 mb-2" />
                <span className="font-medium">Generate QR</span>
              </div>
            </Link>
            
            <Link to="/sessions/new" className="card bg-secondary-50 hover:bg-secondary-100 transition-colors">
              <div className="flex flex-col items-center justify-center py-4">
                <CalendarDays className="h-8 w-8 text-secondary-600 mb-2" />
                <span className="font-medium">New Session</span>
              </div>
            </Link>
            
            <Link to="/reports/view" className="card bg-accent-50 hover:bg-accent-100 transition-colors">
              <div className="flex flex-col items-center justify-center py-4">
                <ClipboardCheck className="h-8 w-8 text-accent-600 mb-2" />
                <span className="font-medium">View Reports</span>
              </div>
            </Link>
            
            <Link to="/notifications" className="card bg-warning-50 hover:bg-warning-100 transition-colors">
              <div className="flex flex-col items-center justify-center py-4">
                <Bell className="h-8 w-8 text-warning-600 mb-2" />
                <span className="font-medium">Notifications</span>
              </div>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

const StudentDashboard: React.FC = () => {
  return (
    <div>
      {/* Summary stats */}
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4 mb-8">
        <div className="card flex items-center">
          <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-primary-100">
            <CalendarDays className="h-6 w-6 text-primary-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">My Courses</p>
            <p className="text-2xl font-semibold">5</p>
          </div>
        </div>
        
        <div className="card flex items-center">
          <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-success-100">
            <ClipboardCheck className="h-6 w-6 text-success-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Attendance Rate</p>
            <p className="text-2xl font-semibold">95%</p>
          </div>
        </div>
        
        <div className="card flex items-center">
          <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-warning-100">
            <Clock className="h-6 w-6 text-warning-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Late Check-ins</p>
            <p className="text-2xl font-semibold">3</p>
          </div>
        </div>
        
        <div className="card flex items-center">
          <div className="mr-4 flex h-12 w-12 items-center justify-center rounded-full bg-error-100">
            <XCircle className="h-6 w-6 text-error-600" />
          </div>
          <div>
            <p className="text-sm font-medium text-gray-500">Absences</p>
            <p className="text-2xl font-semibold">2</p>
          </div>
        </div>
      </div>
      
      {/* Today's classes and attendance history */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
        <div>
          <div className="card h-full">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Today's Classes</h2>
            </div>
            <div className="space-y-4">
              <div className="rounded-lg border border-gray-200 bg-white p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold">CS301: Data Structures</h3>
                  <span className="inline-flex items-center rounded-full bg-success-100 px-2.5 py-0.5 text-xs font-medium text-success-800">
                    Attended
                  </span>
                </div>
                <div className="flex items-center text-sm text-gray-500">
                  <Clock className="mr-1 h-4 w-4" />
                  <span>10:00 AM - 11:30 AM</span>
                </div>
              </div>
              
              <div className="rounded-lg border border-gray-200 bg-white p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold">CS401: Algorithms</h3>
                  <span className="inline-flex items-center rounded-full bg-warning-100 px-2.5 py-0.5 text-xs font-medium text-warning-800">
                    Upcoming
                  </span>
                </div>
                <div className="flex items-center text-sm text-gray-500">
                  <Clock className="mr-1 h-4 w-4" />
                  <span>2:00 PM - 3:30 PM</span>
                </div>
              </div>
              
              <div className="rounded-lg border border-gray-200 bg-white p-4">
                <div className="flex items-center justify-between mb-2">
                  <h3 className="font-semibold">CS201: Software Engineering</h3>
                  <span className="inline-flex items-center rounded-full bg-warning-100 px-2.5 py-0.5 text-xs font-medium text-warning-800">
                    Upcoming
                  </span>
                </div>
                <div className="flex items-center text-sm text-gray-500">
                  <Clock className="mr-1 h-4 w-4" />
                  <span>4:00 PM - 5:30 PM</span>
                </div>
              </div>
            </div>
          </div>
        </div>
        
        <div className="lg:col-span-2">
          <div className="card h-full">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold">Attendance History</h2>
              <Link to="/history" className="flex items-center text-sm text-primary-600 hover:text-primary-500">
                View full history
                <ArrowUpRight className="ml-1 h-4 w-4" />
              </Link>
            </div>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Class
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Date
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Time
                    </th>
                    <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">CS301: Data Structures</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">2025-01-07</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">10:00 AM</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="inline-flex items-center rounded-full bg-success-100 px-2.5 py-0.5 text-xs font-medium text-success-800">
                        Present
                      </span>
                    </td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">CS201: Software Engineering</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">2025-01-06</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">4:00 PM</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="inline-flex items-center rounded-full bg-success-100 px-2.5 py-0.5 text-xs font-medium text-success-800">
                        Present
                      </span>
                    </td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">CS401: Algorithms</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">2025-01-06</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">2:00 PM</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="inline-flex items-center rounded-full bg-warning-100 px-2.5 py-0.5 text-xs font-medium text-warning-800">
                        Late
                      </span>
                    </td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm font-medium text-gray-900">CS101: Intro to Programming</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">2025-01-05</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <div className="text-sm text-gray-500">9:00 AM</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className="inline-flex items-center rounded-full bg-error-100 px-2.5 py-0.5 text-xs font-medium text-error-800">
                        Absent
                      </span>
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      </div>
      
      {/* Student quick actions */}
      <div className="grid grid-cols-1 gap-6">
        <div className="card">
          <h2 className="text-lg font-semibold mb-4">Quick Actions</h2>
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <Link to="/scan" className="card bg-primary-50 hover:bg-primary-100 transition-colors">
              <div className="flex flex-col items-center justify-center py-4">
                <QrCode className="h-8 w-8 text-primary-600 mb-2" />
                <span className="font-medium">Scan QR Code</span>
              </div>
            </Link>
            
            <Link to="/history" className="card bg-secondary-50 hover:bg-secondary-100 transition-colors">
              <div className="flex flex-col items-center justify-center py-4">
                <ClipboardCheck className="h-8 w-8 text-secondary-600 mb-2" />
                <span className="font-medium">My Attendance</span>
              </div>
            </Link>
            
            <Link to="/settings" className="card bg-accent-50 hover:bg-accent-100 transition-colors">
              <div className="flex flex-col items-center justify-center py-4">
                <Settings className="h-8 w-8 text-accent-600 mb-2" />
                <span className="font-medium">Settings</span>
              </div>
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;