import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { 
  User, 
  Bell, 
  Mail, 
  MapPin, 
  Lock, 
  Phone,
  Save,
  CheckCircle,
  Shield,
  AlertTriangle
} from 'lucide-react';

const Settings: React.FC = () => {
  const { currentUser } = useAuth();
  
  // User info state
  const [userInfo, setUserInfo] = useState({
    name: currentUser?.name || '',
    email: currentUser?.email || '',
    phone: '+1 (555) 123-4567',
    role: currentUser?.role || 'student',
    profileImage: currentUser?.avatarUrl,
  });
  
  // Notification settings
  const [notificationSettings, setNotificationSettings] = useState({
    emailNotifications: true,
    pushNotifications: false,
    absenceAlerts: true,
    weeklyReports: true,
    locationTracking: true,
  });
  
  // Privacy settings
  const [privacySettings, setPrivacySettings] = useState({
    showAttendanceToAll: false,
    shareLocationData: true,
    allowAnalytics: true,
  });
  
  // State for save confirmation
  const [saveSuccess, setSaveSuccess] = useState(false);
  
  // Handle form input changes
  const handleUserInfoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setUserInfo({
      ...userInfo,
      [e.target.name]: e.target.value,
    });
  };
  
  // Handle notification toggle changes
  const handleNotificationChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setNotificationSettings({
      ...notificationSettings,
      [e.target.name]: e.target.checked,
    });
  };
  
  // Handle privacy toggle changes
  const handlePrivacyChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPrivacySettings({
      ...privacySettings,
      [e.target.name]: e.target.checked,
    });
  };
  
  // Save settings
  const handleSaveSettings = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Mock API call to save settings
    // In a real app, this would make an API call
    setTimeout(() => {
      setSaveSuccess(true);
      setTimeout(() => setSaveSuccess(false), 3000);
    }, 1000);
  };
  
  return (
    <div className="animate-fade-in">
      <h1 className="text-2xl font-bold mb-6">Settings</h1>
      
      <div className="grid grid-cols-1 gap-8 lg:grid-cols-3">
        {/* User Profile */}
        <div className="lg:col-span-2">
          <div className="card mb-8">
            <div className="flex items-center gap-3 mb-6">
              <User className="h-5 w-5 text-primary-600" />
              <h2 className="text-lg font-semibold">User Profile</h2>
            </div>
            
            <form onSubmit={handleSaveSettings}>
              <div className="flex flex-col md:flex-row gap-6 mb-6">
                <div className="md:w-1/3 flex flex-col items-center justify-start">
                  <div className="relative">
                    <div className="h-24 w-24 rounded-full overflow-hidden bg-gray-200 mb-4">
                      {userInfo.profileImage ? (
                        <img 
                          src={userInfo.profileImage} 
                          alt={userInfo.name} 
                          className="h-full w-full object-cover"
                        />
                      ) : (
                        <div className="h-full w-full flex items-center justify-center">
                          <User size={40} className="text-gray-400" />
                        </div>
                      )}
                    </div>
                    <button 
                      type="button"
                      className="btn btn-sm btn-outline absolute -bottom-2 left-1/2 transform -translate-x-1/2"
                    >
                      Change
                    </button>
                  </div>
                  
                  <div className="text-center mt-6">
                    <p className="text-sm font-medium text-gray-700">{userInfo.role.toUpperCase()}</p>
                    <p className="text-sm text-gray-500">Member since 2025</p>
                  </div>
                </div>
                
                <div className="md:w-2/3">
                  <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
                    <div>
                      <label htmlFor="name" className="form-label">Full Name</label>
                      <input
                        id="name"
                        name="name"
                        type="text"
                        value={userInfo.name}
                        onChange={handleUserInfoChange}
                        className="form-input"
                        required
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="email" className="form-label">Email Address</label>
                      <input
                        id="email"
                        name="email"
                        type="email"
                        value={userInfo.email}
                        onChange={handleUserInfoChange}
                        className="form-input"
                        required
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="phone" className="form-label">Phone Number</label>
                      <input
                        id="phone"
                        name="phone"
                        type="tel"
                        value={userInfo.phone}
                        onChange={handleUserInfoChange}
                        className="form-input"
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="role" className="form-label">Role</label>
                      <input
                        id="role"
                        type="text"
                        value={userInfo.role}
                        className="form-input bg-gray-50"
                        disabled
                      />
                    </div>
                  </div>
                </div>
              </div>
            </form>
          </div>
          
          {/* Notification Settings */}
          <div className="card mb-8">
            <div className="flex items-center gap-3 mb-6">
              <Bell className="h-5 w-5 text-primary-600" />
              <h2 className="text-lg font-semibold">Notification Settings</h2>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Email Notifications</p>
                  <p className="text-sm text-gray-500">Receive attendance updates via email</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    name="emailNotifications" 
                    className="sr-only peer" 
                    checked={notificationSettings.emailNotifications}
                    onChange={handleNotificationChange}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
                </label>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Push Notifications</p>
                  <p className="text-sm text-gray-500">Receive alerts on your device</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    name="pushNotifications" 
                    className="sr-only peer" 
                    checked={notificationSettings.pushNotifications}
                    onChange={handleNotificationChange}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
                </label>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Absence Alerts</p>
                  <p className="text-sm text-gray-500">Get notified about absence or late attendance</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    name="absenceAlerts" 
                    className="sr-only peer" 
                    checked={notificationSettings.absenceAlerts}
                    onChange={handleNotificationChange}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
                </label>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Weekly Reports</p>
                  <p className="text-sm text-gray-500">Receive weekly attendance summary reports</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    name="weeklyReports" 
                    className="sr-only peer" 
                    checked={notificationSettings.weeklyReports}
                    onChange={handleNotificationChange}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
                </label>
              </div>
            </div>
          </div>
          
          {/* Privacy Settings */}
          <div className="card">
            <div className="flex items-center gap-3 mb-6">
              <Shield className="h-5 w-5 text-primary-600" />
              <h2 className="text-lg font-semibold">Privacy Settings</h2>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Location Tracking</p>
                  <p className="text-sm text-gray-500">Allow location verification for attendance</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    name="locationTracking" 
                    className="sr-only peer" 
                    checked={notificationSettings.locationTracking}
                    onChange={handleNotificationChange}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
                </label>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Show Attendance to Others</p>
                  <p className="text-sm text-gray-500">Make your attendance visible to classmates</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    name="showAttendanceToAll" 
                    className="sr-only peer" 
                    checked={privacySettings.showAttendanceToAll}
                    onChange={handlePrivacyChange}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
                </label>
              </div>
              
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Usage Analytics</p>
                  <p className="text-sm text-gray-500">Allow anonymous usage data collection</p>
                </div>
                <label className="relative inline-flex items-center cursor-pointer">
                  <input 
                    type="checkbox" 
                    name="allowAnalytics" 
                    className="sr-only peer" 
                    checked={privacySettings.allowAnalytics}
                    onChange={handlePrivacyChange}
                  />
                  <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-600"></div>
                </label>
              </div>
            </div>
          </div>
        </div>
        
        {/* Right Sidebar */}
        <div className="space-y-8">
          {/* Account Info Card */}
          <div className="card bg-primary-50">
            <div className="flex items-center gap-3 mb-4">
              <User className="h-5 w-5 text-primary-600" />
              <h2 className="text-lg font-semibold">Account Info</h2>
            </div>
            
            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <Mail className="h-5 w-5 text-gray-500 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-gray-700">Email</p>
                  <p className="text-sm text-gray-600">{userInfo.email}</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <Phone className="h-5 w-5 text-gray-500 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-gray-700">Phone</p>
                  <p className="text-sm text-gray-600">{userInfo.phone}</p>
                </div>
              </div>
              
              <div className="flex items-start gap-3">
                <MapPin className="h-5 w-5 text-gray-500 flex-shrink-0 mt-0.5" />
                <div>
                  <p className="text-sm font-medium text-gray-700">Default Location</p>
                  <p className="text-sm text-gray-600">Main Campus, Building 3</p>
                </div>
              </div>
            </div>
            
            <div className="mt-6 pt-4 border-t border-gray-200">
              <button className="w-full btn btn-outline flex items-center justify-center gap-2">
                <Lock size={16} />
                Change Password
              </button>
            </div>
          </div>
          
          {/* Email Integration */}
          <div className="card">
            <div className="flex items-center gap-3 mb-4">
              <Mail className="h-5 w-5 text-primary-600" />
              <h2 className="text-lg font-semibold">Email Integration</h2>
            </div>
            
            <p className="text-sm text-gray-600 mb-4">
              Connect your Gmail account to get automated attendance reports and notifications.
            </p>
            
            <button className="w-full btn btn-outline mb-4">
              Connect Gmail
            </button>
            
            <div className="p-3 bg-warning-50 rounded-md">
              <div className="flex items-start gap-2">
                <AlertTriangle className="h-5 w-5 text-warning-500 flex-shrink-0 mt-0.5" />
                <p className="text-sm text-warning-700">
                  Email integration allows the system to send attendance reports and notifications directly to your inbox.
                </p>
              </div>
            </div>
          </div>
          
          {/* Save Settings */}
          <div className="card">
            <button 
              onClick={handleSaveSettings} 
              className="w-full btn btn-primary flex items-center justify-center gap-2"
            >
              {saveSuccess ? (
                <>
                  <CheckCircle size={18} />
                  Settings Saved!
                </>
              ) : (
                <>
                  <Save size={18} />
                  Save All Settings
                </>
              )}
            </button>
            
            <p className="text-sm text-gray-500 text-center mt-4">
              Last updated: {new Date().toLocaleDateString()} at {new Date().toLocaleTimeString()}
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Settings;