export interface Meal {
  id: string;
  name: string;
  description: string;
  price: number;
  imageUrl: string;
  calories: number;
  macros: {
    protein: number;
    carbs: number;
    fat: number;
  };
  ingredients: string[];
  preparationTime: number;
  category: 'breakfast' | 'lunch' | 'dinner' | 'snack';
}

export interface CartItem {
  meal: Meal;
  quantity: number;
}

export interface UserHealth {
  dailyCalorieGoal: number;
  waterIntakeGoal: number;
  stepsGoal: number;
  currentWaterIntake: number;
  currentSteps: number;
  consumedCalories: number;
}