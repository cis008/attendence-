import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { UserHealth } from '../types/meal';

interface HealthStore extends UserHealth {
  addWater: (amount: number) => void;
  addSteps: (steps: number) => void;
  addCalories: (calories: number) => void;
  resetDaily: () => void;
  updateGoals: (goals: Partial<UserHealth>) => void;
}

export const useHealthStore = create<HealthStore>()(
  persist(
    (set) => ({
      dailyCalorieGoal: 2000,
      waterIntakeGoal: 2000,
      stepsGoal: 10000,
      currentWaterIntake: 0,
      currentSteps: 0,
      consumedCalories: 0,

      addWater: (amount) =>
        set((state) => ({
          currentWaterIntake: state.currentWaterIntake + amount,
        })),

      addSteps: (steps) =>
        set((state) => ({
          currentSteps: state.currentSteps + steps,
        })),

      addCalories: (calories) =>
        set((state) => ({
          consumedCalories: state.consumedCalories + calories,
        })),

      resetDaily: () =>
        set({
          currentWaterIntake: 0,
          currentSteps: 0,
          consumedCalories: 0,
        }),

      updateGoals: (goals) =>
        set((state) => ({
          ...state,
          ...goals,
        })),
    }),
    {
      name: 'health-store',
    }
  )
);