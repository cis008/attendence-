import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { CartItem, Meal } from '../types/meal';

interface CartStore {
  items: CartItem[];
  addItem: (meal: Meal) => void;
  removeItem: (mealId: string) => void;
  updateQuantity: (mealId: string, quantity: number) => void;
  clearCart: () => void;
  total: number;
}

export const useCartStore = create<CartStore>()(
  persist(
    (set, get) => ({
      items: [],
      
      addItem: (meal) => {
        set((state) => {
          const existingItem = state.items.find((item) => item.meal.id === meal.id);
          
          if (existingItem) {
            return {
              items: state.items.map((item) =>
                item.meal.id === meal.id
                  ? { ...item, quantity: item.quantity + 1 }
                  : item
              ),
            };
          }
          
          return {
            items: [...state.items, { meal, quantity: 1 }],
          };
        });
      },
      
      removeItem: (mealId) => {
        set((state) => ({
          items: state.items.filter((item) => item.meal.id !== mealId),
        }));
      },
      
      updateQuantity: (mealId, quantity) => {
        set((state) => ({
          items: state.items.map((item) =>
            item.meal.id === mealId ? { ...item, quantity } : item
          ),
        }));
      },
      
      clearCart: () => set({ items: [] }),
      
      get total() {
        return get().items.reduce(
          (sum, item) => sum + item.meal.price * item.quantity,
          0
        );
      },
    }),
    {
      name: 'cart-store',
    }
  )
);