import React, { createContext, useContext, useState, useEffect } from 'react';

// Define types for user and context
export type UserRole = 'admin' | 'instructor' | 'student';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
  avatarUrl?: string;
}

interface AuthContextType {
  currentUser: User | null;
  loading: boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (name: string, email: string, password: string, role: UserRole) => Promise<void>;
  logout: () => void;
  isAuthenticated: boolean;
}

// Create context with default values
const AuthContext = createContext<AuthContextType>({
  currentUser: null,
  loading: true,
  login: async () => {},
  register: async () => {},
  logout: () => {},
  isAuthenticated: false,
});

// Sample user data for demonstration
const mockUsers = [
  {
    id: '1',
    name: 'Admin User',
    email: 'admin@example.com',
    password: 'password123',
    role: 'admin' as UserRole,
    avatarUrl: 'https://i.pravatar.cc/150?u=admin',
  },
  {
    id: '2',
    name: 'John Instructor',
    email: 'instructor@example.com',
    password: 'password123',
    role: 'instructor' as UserRole,
    avatarUrl: 'https://i.pravatar.cc/150?u=instructor',
  },
  {
    id: '3',
    name: 'Jane Student',
    email: 'student@example.com',
    password: 'password123',
    role: 'student' as UserRole,
    avatarUrl: 'https://i.pravatar.cc/150?u=student',
  },
];

// Create provider component
export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);

  // Check if user is already logged in
  useEffect(() => {
    const storedUser = localStorage.getItem('attendanceAppUser');
    if (storedUser) {
      try {
        setCurrentUser(JSON.parse(storedUser));
      } catch (error) {
        console.error('Failed to parse stored user:', error);
        localStorage.removeItem('attendanceAppUser');
      }
    }
    setLoading(false);
  }, []);

  // Mock login functionality
  const login = async (email: string, password: string) => {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Trim email and ensure case-insensitive comparison
    const normalizedEmail = email.trim().toLowerCase();
    const user = mockUsers.find(u => 
      u.email.toLowerCase() === normalizedEmail && 
      u.password === password
    );
    
    if (!user) {
      throw new Error('Invalid email or password');
    }
    
    const { password: _, ...userWithoutPassword } = user;
    setCurrentUser(userWithoutPassword);
    localStorage.setItem('attendanceAppUser', JSON.stringify(userWithoutPassword));
  };

  // Mock register functionality
  const register = async (name: string, email: string, password: string, role: UserRole) => {
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Check if user exists
    if (mockUsers.some(u => u.email === email)) {
      throw new Error('Email already in use');
    }
    
    // Create new user (in a real app, this would be an API call)
    const newUser = {
      id: `${mockUsers.length + 1}`,
      name,
      email,
      role,
      avatarUrl: `https://i.pravatar.cc/150?u=${email}`,
    };
    
    setCurrentUser(newUser);
    localStorage.setItem('attendanceAppUser', JSON.stringify(newUser));
  };

  // Logout functionality
  const logout = () => {
    setCurrentUser(null);
    localStorage.removeItem('attendanceAppUser');
  };

  const value = {
    currentUser,
    loading,
    login,
    register,
    logout,
    isAuthenticated: !!currentUser,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};

// Custom hook for using auth context
export const useAuth = () => useContext(AuthContext);