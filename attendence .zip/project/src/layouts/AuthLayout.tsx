import React from 'react';
import { Outlet, Navigate } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { QrCode } from 'lucide-react';

const AuthLayout: React.FC = () => {
  const { isAuthenticated, loading } = useAuth();

  // Show loading indicator while checking authentication
  if (loading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-600"></div>
      </div>
    );
  }

  // Redirect to dashboard if already authenticated
  if (isAuthenticated) {
    return <Navigate to="/dashboard" replace />;
  }

  return (
    <div className="flex min-h-screen bg-gray-100">
      {/* Left side - auth form */}
      <div className="flex w-full items-center justify-center p-6 lg:w-1/2">
        <div className="w-full max-w-md">
          <div className="mb-8 flex items-center justify-center">
            <div className="mr-3 flex h-12 w-12 items-center justify-center rounded-full bg-primary-600 text-white">
              <QrCode size={24} />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">AttendanceHub</h1>
          </div>
          
          {/* Outlet for Login/Register components */}
          <Outlet />
        </div>
      </div>
      
      {/* Right side - hero image and info (hidden on mobile) */}
      <div className="hidden lg:block lg:w-1/2 bg-gradient-to-br from-primary-600 to-secondary-600">
        <div className="flex h-full flex-col items-center justify-center p-12 text-white">
          <h2 className="mb-4 text-4xl font-bold">Modern Attendance Tracking</h2>
          <p className="mb-8 text-center text-xl">
            Streamline your attendance management with QR code check-ins, GPS verification,
            and real-time reporting.
          </p>
          <div className="grid grid-cols-2 gap-8">
            <div className="rounded-lg bg-white bg-opacity-10 p-4">
              <h3 className="mb-2 text-xl font-semibold">QR Check-ins</h3>
              <p>Quick and reliable attendance tracking with QR code verification.</p>
            </div>
            <div className="rounded-lg bg-white bg-opacity-10 p-4">
              <h3 className="mb-2 text-xl font-semibold">Location Verification</h3>
              <p>Ensure check-ins are valid with GPS-based location verification.</p>
            </div>
            <div className="rounded-lg bg-white bg-opacity-10 p-4">
              <h3 className="mb-2 text-xl font-semibold">Real-time Reporting</h3>
              <p>Access attendance data instantly with comprehensive reports.</p>
            </div>
            <div className="rounded-lg bg-white bg-opacity-10 p-4">
              <h3 className="mb-2 text-xl font-semibold">Email Notifications</h3>
              <p>Automated alerts for absences and attendance confirmations.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthLayout;