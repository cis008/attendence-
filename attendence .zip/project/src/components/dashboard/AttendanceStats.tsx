import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

interface AttendanceData {
  date: string;
  present: number;
  absent: number;
}

interface AttendanceStatsProps {
  data: AttendanceData[];
}

export const AttendanceStats: React.FC<AttendanceStatsProps> = ({ data }) => {
  // Format the date for display in chart
  const formattedData = data.map(item => ({
    ...item,
    date: new Date(item.date).toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  }));

  return (
    <div className="h-[300px]">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart
          data={formattedData}
          margin={{
            top: 20,
            right: 30,
            left: 0,
            bottom: 20,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" vertical={false} />
          <XAxis 
            dataKey="date" 
            tick={{ fontSize: 12 }}
            axisLine={{ stroke: '#E5E7EB' }}
            tickLine={false}
          />
          <YAxis 
            width={40}
            tick={{ fontSize: 12 }}
            axisLine={{ stroke: '#E5E7EB' }}
            tickLine={false}
            domain={[0, 100]}
            tickFormatter={(value) => `${value}%`}
          />
          <Tooltip 
            formatter={(value) => [`${value}%`, '']}
            contentStyle={{
              backgroundColor: 'white',
              borderRadius: '8px',
              boxShadow: '0 1px 3px rgba(0, 0, 0, 0.1), 0 1px 2px rgba(0, 0, 0, 0.06)',
              border: 'none',
              padding: '8px 12px',
            }}
          />
          <Legend 
            wrapperStyle={{ paddingTop: '15px' }}
            formatter={(value) => <span style={{ color: '#374151', fontSize: '12px' }}>{value}</span>}
          />
          <Bar 
            dataKey="present" 
            stackId="a" 
            fill="#22C55E" 
            name="Present" 
            radius={[4, 4, 0, 0]}
          />
          <Bar 
            dataKey="absent" 
            stackId="a" 
            fill="#EF4444" 
            name="Absent" 
            radius={[4, 4, 0, 0]}
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
};