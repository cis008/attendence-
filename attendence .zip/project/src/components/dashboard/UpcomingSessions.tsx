import React from 'react';
import { Clock, MapPin, Users } from 'lucide-react';

// Mock data for upcoming sessions
const upcomingSessions = [
  {
    id: 1,
    title: 'CS101: Intro to Programming',
    time: '2:00 PM - 3:30 PM',
    location: 'Room 301',
    students: 32,
  },
  {
    id: 2,
    title: 'CS201: Software Engineering',
    time: '4:00 PM - 5:30 PM',
    location: 'Room 201',
    students: 28,
  },
  {
    id: 3,
    title: 'CS301: Data Structures',
    time: '10:00 AM - 11:30 AM',
    location: 'Room 101',
    students: 24,
    isTomorrow: true,
  },
];

export const UpcomingSessions: React.FC = () => {
  return (
    <div className="space-y-4">
      {upcomingSessions.map((session) => (
        <div
          key={session.id}
          className="rounded-lg border border-gray-200 bg-white p-4 transition-shadow hover:shadow-md"
        >
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">{session.title}</h3>
            {session.isTomorrow ? (
              <span className="inline-flex items-center rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-800">
                Tomorrow
              </span>
            ) : (
              <span className="inline-flex items-center rounded-full bg-primary-100 px-2.5 py-0.5 text-xs font-medium text-primary-800">
                Today
              </span>
            )}
          </div>
          
          <div className="mt-2 space-y-2">
            <div className="flex items-center text-sm text-gray-500">
              <Clock className="mr-2 h-4 w-4" />
              <span>{session.time}</span>
            </div>
            
            <div className="flex items-center text-sm text-gray-500">
              <MapPin className="mr-2 h-4 w-4" />
              <span>{session.location}</span>
            </div>
            
            <div className="flex items-center text-sm text-gray-500">
              <Users className="mr-2 h-4 w-4" />
              <span>{session.students} students enrolled</span>
            </div>
          </div>
        </div>
      ))}
    </div>
  );
};