import React from 'react';
import { Clock, User, Check, AlertTriangle } from 'lucide-react';

// Mock data for recent activities
const recentActivities = [
  {
    id: 1,
    action: 'checked in',
    user: 'Jane Student',
    course: 'CS301: Data Structures',
    time: '10:15 AM',
    status: 'success',
  },
  {
    id: 2,
    action: 'checked in',
    user: 'John Student',
    course: 'CS401: Algorithms',
    time: '09:58 AM',
    status: 'success',
  },
  {
    id: 3,
    action: 'was absent',
    user: 'Sam Student',
    course: 'CS201: Software Engineering',
    time: '09:30 AM',
    status: 'warning',
  },
  {
    id: 4,
    action: 'checked in late',
    user: 'Alex Student',
    course: 'CS101: Intro to Programming',
    time: '09:15 AM',
    status: 'warning',
  },
  {
    id: 5,
    action: 'checked in',
    user: 'Taylor Student',
    course: 'CS301: Data Structures',
    time: '09:05 AM',
    status: 'success',
  },
];

export const RecentActivity: React.FC = () => {
  return (
    <div className="space-y-4">
      {recentActivities.map((activity) => (
        <div key={activity.id} className="flex items-start gap-3">
          <div className={`flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full ${
            activity.status === 'success' ? 'bg-success-100' : 'bg-warning-100'
          }`}>
            {activity.status === 'success' ? (
              <Check className="h-4 w-4 text-success-600" />
            ) : (
              <AlertTriangle className="h-4 w-4 text-warning-600" />
            )}
          </div>
          
          <div className="flex-1 min-w-0">
            <div className="flex items-center justify-between">
              <p className="font-medium text-gray-900 truncate">
                {activity.user}
              </p>
              <p className="text-xs text-gray-500 ml-2 whitespace-nowrap">
                {activity.time}
              </p>
            </div>
            <p className="text-sm text-gray-600">
              {activity.action} for {activity.course}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
};