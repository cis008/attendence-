import React from 'react';
import { ShoppingCart, Info } from 'lucide-react';
import type { Meal } from '../../types/meal';
import { useCartStore } from '../../stores/cartStore';
import { useHealthStore } from '../../stores/healthStore';

interface MealCardProps {
  meal: Meal;
}

export const MealCard: React.FC<MealCardProps> = ({ meal }) => {
  const addToCart = useCartStore((state) => state.addItem);
  const addCalories = useHealthStore((state) => state.addCalories);
  
  const handleAddToCart = () => {
    addToCart(meal);
    addCalories(meal.calories);
  };
  
  return (
    <div className="card overflow-hidden">
      <img
        src={meal.imageUrl}
        alt={meal.name}
        className="w-full h-48 object-cover"
      />
      
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <h3 className="font-semibold text-lg">{meal.name}</h3>
          <span className="font-semibold text-primary-600">
            ${meal.price.toFixed(2)}
          </span>
        </div>
        
        <p className="text-sm text-gray-600 mb-4">{meal.description}</p>
        
        <div className="grid grid-cols-3 gap-2 mb-4 text-center text-sm">
          <div className="bg-gray-50 p-2 rounded">
            <p className="font-semibold">{meal.macros.protein}g</p>
            <p className="text-gray-600">Protein</p>
          </div>
          <div className="bg-gray-50 p-2 rounded">
            <p className="font-semibold">{meal.macros.carbs}g</p>
            <p className="text-gray-600">Carbs</p>
          </div>
          <div className="bg-gray-50 p-2 rounded">
            <p className="font-semibold">{meal.macros.fat}g</p>
            <p className="text-gray-600">Fat</p>
          </div>
        </div>
        
        <div className="flex gap-2">
          <button
            onClick={handleAddToCart}
            className="btn btn-primary flex-1"
          >
            <ShoppingCart className="h-4 w-4 mr-2" />
            Add to Cart
          </button>
          <button className="btn btn-outline p-2">
            <Info className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  );
};