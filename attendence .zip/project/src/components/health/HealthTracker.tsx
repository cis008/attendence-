import React from 'react';
import { Droplets, Footprints, Scale } from 'lucide-react';
import { useHealthStore } from '../../stores/healthStore';

export const HealthTracker: React.FC = () => {
  const health = useHealthStore();
  
  const waterProgress = (health.currentWaterIntake / health.waterIntakeGoal) * 100;
  const stepsProgress = (health.currentSteps / health.stepsGoal) * 100;
  const caloriesProgress = (health.consumedCalories / health.dailyCalorieGoal) * 100;
  
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
      <div className="card p-4">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-blue-100 rounded-full">
            <Droplets className="h-6 w-6 text-blue-600" />
          </div>
          <div>
            <h3 className="font-semibold">Water Intake</h3>
            <p className="text-sm text-gray-600">
              {health.currentWaterIntake}ml / {health.waterIntakeGoal}ml
            </p>
          </div>
        </div>
        <div className="h-2 bg-gray-200 rounded-full">
          <div
            className="h-full bg-blue-600 rounded-full transition-all"
            style={{ width: `${Math.min(waterProgress, 100)}%` }}
          />
        </div>
        <button
          onClick={() => health.addWater(250)}
          className="mt-2 w-full btn btn-sm btn-outline"
        >
          Add 250ml
        </button>
      </div>

      <div className="card p-4">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-green-100 rounded-full">
            <Footprints className="h-6 w-6 text-green-600" />
          </div>
          <div>
            <h3 className="font-semibold">Steps</h3>
            <p className="text-sm text-gray-600">
              {health.currentSteps} / {health.stepsGoal}
            </p>
          </div>
        </div>
        <div className="h-2 bg-gray-200 rounded-full">
          <div
            className="h-full bg-green-600 rounded-full transition-all"
            style={{ width: `${Math.min(stepsProgress, 100)}%` }}
          />
        </div>
        <button
          onClick={() => health.addSteps(100)}
          className="mt-2 w-full btn btn-sm btn-outline"
        >
          Add Steps
        </button>
      </div>

      <div className="card p-4">
        <div className="flex items-center gap-3 mb-2">
          <div className="p-2 bg-orange-100 rounded-full">
            <Scale className="h-6 w-6 text-orange-600" />
          </div>
          <div>
            <h3 className="font-semibold">Calories</h3>
            <p className="text-sm text-gray-600">
              {health.consumedCalories} / {health.dailyCalorieGoal}
            </p>
          </div>
        </div>
        <div className="h-2 bg-gray-200 rounded-full">
          <div
            className="h-full bg-orange-600 rounded-full transition-all"
            style={{ width: `${Math.min(caloriesProgress, 100)}%` }}
          />
        </div>
      </div>
    </div>
  );
};